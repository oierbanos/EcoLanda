package launcher;

public enum TipoDato {

    TEMPERATURA, HUMEDAD, PESO, VACIO;
}
